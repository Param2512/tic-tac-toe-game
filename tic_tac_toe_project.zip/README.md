# Tic-Tac-Toe Game (C++)

🎮 A simple console-based Tic-Tac-Toe game written in C++.

## 📋 Features

- Two-player (Human vs Human) gameplay
- Players take turns to place their marks (`X` and `O`) on a 3×3 board
- Detects winner or declares a draw
- Validates moves

## 🧑‍💻 How to Play

1️⃣ Player 1 is `X`, Player 2 is `O`.  
2️⃣ On your turn, enter the row and column numbers (`0`, `1`, or `2`) where you want to place your mark.  
3️⃣ The first player to align three marks horizontally, vertically, or diagonally wins!  
4️⃣ If the board fills up with no winner, it’s a draw.

## 🚀 Running the Code

### Compile
```bash
g++ tic_tac_toe_with_comment.cpp -o tic_tac_toe
```

### Run
```bash
./tic_tac_toe
```

## 📅 Author

Param Kumar  
July 2025

---

> Feel free to fork and improve — maybe add an AI opponent or a nicer UI! 🙂