/*
 * Tic-Tac-Toe Game (Human vs Human)
 * ---------------------------------
 * A simple console-based Tic-Tac-Toe game written in C++.
 * Players take turns entering row and column numbers (0–2) to place their marks.
 *
 * Author: Param Kumar
 * Date: July 2025
 */

#include <iostream>
using namespace std;

char board[3][3];
char current_marker;
int current_player;

void drawBoard() {
    cout << "\n";
    for (int i = 0; i < 3; i++) {
        cout << " ";
        for (int j = 0; j < 3; j++) {
            cout << board[i][j];
            if (j < 2) cout << " | ";
        }
        cout << "\n";
        if (i < 2) cout << "---|---|---\n";
    }
    cout << "\n";
}

bool placeMarker(int row, int col) {
    if (row >= 0 && row < 3 && col >= 0 && col < 3 && board[row][col] == ' ') {
        board[row][col] = current_marker;
        return true;
    }
    return false;
}

int checkWinner() {
    for (int i = 0; i < 3; i++) {
        if (board[i][0] == current_marker && board[i][1] == current_marker && board[i][2] == current_marker)
            return current_player;
        if (board[0][i] == current_marker && board[1][i] == current_marker && board[2][i] == current_marker)
            return current_player;
    }
    if (board[0][0] == current_marker && board[1][1] == current_marker && board[2][2] == current_marker)
        return current_player;
    if (board[0][2] == current_marker && board[1][1] == current_marker && board[2][0] == current_marker)
        return current_player;

    return 0;
}

void swapPlayer() {
    if (current_marker == 'X') {
        current_marker = 'O';
        current_player = 2;
    } else {
        current_marker = 'X';
        current_player = 1;
    }
}

int main() {
    cout << "Tic-Tac-Toe Game (Human vs Human)\n";
    cout << "Player 1: X\nPlayer 2: O\n";

    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            board[i][j] = ' ';

    current_marker = 'X';
    current_player = 1;

    int moves = 0;
    int winner = 0;

    while (moves < 9) {
        drawBoard();
        int row, col;
        cout << "Player " << current_player << "'s turn. Enter row and column (0, 1, 2): ";
        cin >> row >> col;

        if (!placeMarker(row, col)) {
            cout << "Invalid move! Try again.\n";
            continue;
        }

        moves++;
        winner = checkWinner();

        if (winner != 0) {
            drawBoard();
            cout << "Player " << winner << " wins! 🎉\n";
            break;
        }

        swapPlayer();
    }

    if (winner == 0) {
        drawBoard();
        cout << "It's a draw!\n";
    }

    return 0;
}

// End of Tic-Tac-Toe game implementation. Thanks for playing! 🙂